#' @docType package
#' @name Signac-package
#' @rdname Signac-package
#'
"_PACKAGE"