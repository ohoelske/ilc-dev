---
name: "\U0001F4DADocumentation"
about: An issue related to https://satijalab.org/signac/
title: ''
labels: documentation
assignees: ''

---

<!-- A clear description of what content at https://satijalab.org/signac or in the Signac function man pages is an issue. -->
