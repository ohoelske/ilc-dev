library(testthat)
library(Signac)

test_check("Signac")
