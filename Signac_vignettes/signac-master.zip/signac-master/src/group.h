#include <Rcpp.h>
#include <zlib.h>
#include <string.h>

using namespace Rcpp;

SEXP groupCommand(std::string fragments);
